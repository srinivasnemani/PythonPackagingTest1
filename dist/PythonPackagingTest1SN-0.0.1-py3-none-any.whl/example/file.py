

class MyClass1:
    def __init__(self, word):
        self.word = word

    def print_a_message(self):
        print(self.word)
